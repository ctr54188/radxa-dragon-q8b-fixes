// SPDX-License-Identifier: GPL-2.0-only
/* One-shot, headless Q8B experiment launcher. Never installs boot entries. */
#include <efi.h>
#include <efilib.h>

#ifndef Q8B_NEXT_GRUB
#define Q8B_NEXT_GRUB u"\\EFI\\q8b-test-20260909\\grub-test.efi"
#endif

static EFI_FILE_HANDLE root;

static void log_line(char *line)
{
	EFI_FILE_HANDLE file;
	UINTN len = 0;
	EFI_STATUS status;
	while (line[len])
		len++;
	if (!root)
		return;
	status = root->Open(root, &file,
		u"\\EFI\\q8b-test-20260909\\launcher.log",
		EFI_FILE_MODE_READ | EFI_FILE_MODE_WRITE | EFI_FILE_MODE_CREATE, 0);
	if (EFI_ERROR(status))
		return;
	file->SetPosition(file, ~((UINT64)0));
	file->Write(file, &len, line);
	file->Flush(file);
	file->Close(file);
}

static void log_status(char *prefix, EFI_STATUS status)
{
	char buf[] = "0x0000000000000000\r\n";
	char hex[] = "0123456789abcdef";
	UINTN i;
	for (i = 0; i < 16; i++)
		buf[17 - i] = hex[((UINT64)status >> (i * 4)) & 15];
	log_line(prefix);
	log_line(": ");
	log_line(buf);
}

static EFI_STATUS load_start(EFI_HANDLE parent, EFI_HANDLE device, CHAR16 *path)
{
	EFI_DEVICE_PATH *dp = FileDevicePath(device, path);
	EFI_HANDLE child;
	EFI_STATUS status;
	if (!dp)
		return EFI_OUT_OF_RESOURCES;
	status = BS->LoadImage(FALSE, parent, dp, NULL, 0, &child);
	FreePool(dp);
	if (EFI_ERROR(status))
		return status;
	/* A successfully started boot-service driver must remain loaded. */
	return BS->StartImage(child, NULL, NULL);
}

EFI_STATUS efi_main(EFI_HANDLE image, EFI_SYSTEM_TABLE *system_table)
{
	EFI_LOADED_IMAGE_PROTOCOL *loaded;
	EFI_FILE_HANDLE arm;
	EFI_STATUS status;
	BOOLEAN run_dsp = FALSE;
	InitializeLib(image, system_table);
	status = BS->HandleProtocol(image, &LoadedImageProtocol, (VOID **)&loaded);
	if (EFI_ERROR(status))
		return status;
	root = LibOpenRoot(loaded->DeviceHandle);
	log_line("Q8B launcher entered\r\n");
	if (root) {
		status = root->Open(root, &arm,
			u"\\EFI\\q8b-test-20260909\\dsp-once.flag",
			EFI_FILE_MODE_READ | EFI_FILE_MODE_WRITE, 0);
		if (status == EFI_SUCCESS) {
			/* Delete closes the handle. A warning is NOT confirmed removal. */
			status = arm->Delete(arm);
			log_status("one-shot flag delete", status);
			if (status == EFI_SUCCESS) {
				/* Verify disappearance before starting any DSP code. */
				status = root->Open(root, &arm,
					u"\\EFI\\q8b-test-20260909\\dsp-once.flag",
					EFI_FILE_MODE_READ, 0);
				if (status == EFI_NOT_FOUND)
					run_dsp = TRUE;
				else if (status == EFI_SUCCESS)
					arm->Close(arm);
			}
		}
	}
	if (run_dsp) {
		log_line("Starting DSP preload driver\r\n");
		status = load_start(image, loaded->DeviceHandle,
			u"\\EFI\\q8b-test-20260909\\qebspilaa64.efi");
		log_status("DSP driver StartImage returned", status);
	} else {
		log_line("DSP preload skipped: no verified one-shot flag\r\n");
	}
	log_line("Starting isolated GRUB with existing Linux kernel\r\n");
	if (root) {
		root->Close(root);
		root = NULL;
	}
	/* This GRUB has embedded configuration; never re-enters the parent menu. */
	status = load_start(image, loaded->DeviceHandle,
		Q8B_NEXT_GRUB);
	Print(u"Q8B isolated GRUB returned: %r\n", status);
	return status;
}
