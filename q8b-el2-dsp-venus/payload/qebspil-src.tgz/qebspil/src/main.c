// SPDX-License-Identifier: GPL-2.0-only
/*
 * Copyright (C) 2025 Stephan Gerhold <stephan@gerhold.net>
 */

#include <efi.h>
#include <efilib.h>

#include "qebspil.h"

EFI_LOADED_IMAGE_PROTOCOL *LoadedImage;
static EFI_EVENT ebs_event;

static UINTN current_el(void)
{
	UINT64 value;

	__asm__ volatile("mrs %0, CurrentEL" : "=r"(value));
	return (value >> 2) & 3;
}

static EFI_STATUS efi_late_ebs(void)
{
	EFI_STATUS status;

	Print(u"Q8B test: late ExitBootServices callback at EL%d\n", current_el());
	status = pil_finish_all();
	Print(u"Q8B test: DSP start result: %r\n", status);
	if (status == EFI_NOT_FOUND)
		return EFI_SUCCESS; /* No remoteprocs found */
	if (EFI_ERROR(status))
		return status;

	/*
	 * Wait a bit to let remoteprocs finish handover.
	 * FIXME: Wait for the SMP2P signals instead
	 */
	return BS->Stall(500 * 1000);
}

static EFI_STATUS efi_dtb_changed(void)
{
	EFI_STATUS status;
	void *dtb;

	/* Free what we prepared last time in case the DTB changed */
	pil_free_all();

	status = LibGetSystemConfigurationTable(&EfiDtbTableGuid, &dtb);
	if (status == EFI_NOT_FOUND)
		return EFI_SUCCESS; /* DTB was removed */
	if (EFI_ERROR(status))
		return status;

	status = dtb_enumerate_rprocs(dtb);
	if (status == EFI_NOT_FOUND)
		return EFI_SUCCESS; /* No remoteprocs found */
	if (EFI_ERROR(status))
		return status;

	/* Register late EBS event (if not already) to start the rprocs later */
	if (!ebs_event) {
		status = event_register_late_ebs_callback(&ebs_event, efi_late_ebs);
		if (EFI_ERROR(status))
			return status;
	}

	return EFI_SUCCESS;
}

EFI_STATUS efi_main(EFI_HANDLE image, EFI_SYSTEM_TABLE *system_table)
{
	EFI_STATUS status;
	EFI_EVENT event;

	InitializeLib(image, system_table);

	Print(u"Q8B DSP preload experiment 20260909, upstream 8e4d9e6, load EL%d\n", current_el());

	status = BS->HandleProtocol(image, &LoadedImageProtocol, (VOID**)&LoadedImage);
	if (EFI_ERROR(status))
		return status;

	status = scm_init();
	if (EFI_ERROR(status))
		return status;

	status = event_register_group_callback(&EfiDtbTableGuid, &event, efi_dtb_changed);
	if (EFI_ERROR(status))
		return status;

	return efi_dtb_changed();
}
