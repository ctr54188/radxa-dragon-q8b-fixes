// SPDX-License-Identifier: GPL-2.0-only
#define Q8B_NEXT_GRUB u"\\EFI\\q8b-test-20260909\\grub-venus.efi"
#include "launcher.c"
